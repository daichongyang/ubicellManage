<template>
  <section>
    </section>  
</template>

<script>
export default {
  data(){
    return{

    }
  },
  methods:{

  },
  mounted(){

  }
}
</script>

<style>

</style>